# MAKMAirlines
A software that performs on-line reservation tasks for an airline company. Some functions of the software include: reserve, cancel, review, change and generate some type of reports for the managers. The confirmation should be sent to the traveler.
